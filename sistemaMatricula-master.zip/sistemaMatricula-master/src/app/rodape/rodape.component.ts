import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'semdf-rodape',
  templateUrl: './rodape.component.html',
  styleUrls: ['./rodape.component.css']
})
export class RodapeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
