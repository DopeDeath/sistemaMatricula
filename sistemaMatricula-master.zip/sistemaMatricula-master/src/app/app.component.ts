import { Component } from '@angular/core';


@Component({
  selector: 'semdf-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'semdf';
}
